package gw.config;

/**
 *  Copyright 2010 Guidewire Software, Inc.
 */
public class DefaultCommonsServiceKernelInit implements ServiceKernelInit
{
  public void init( ServiceKernel services )
  {
    //no overrides
  }
}