package gw.lang.parser;

import gw.util.StreamUtil;

import java.io.IOException;
import java.io.Reader;

/**
 *  Copyright 2010 Guidewire Software, Inc.
 */
public class SourceCodeReader
{
  private CharSequence _strSource;
  private int _iPosition;

  public SourceCodeReader( CharSequence s )
  {
    this (s, 0);
  }

  public SourceCodeReader( CharSequence s, int offset )
  {
    _strSource = s;
    _iPosition = offset;
  }

  public SourceCodeReader( SourceCodeReader otherReader )
  {
    _strSource = otherReader._strSource;
    _iPosition = otherReader._iPosition;
  }

  public int read() throws IOException
  {
    try
    {
      return _strSource.charAt( _iPosition++ );
    }
    catch( StringIndexOutOfBoundsException ex )
    {
      return -1;
    }
  }

  public int peek()
  {
    try
    {
      return _strSource.charAt( _iPosition );
    }
    catch( StringIndexOutOfBoundsException ex )
    {
      return -1;
    }
  }

  public int getPosition()
  {
    return _iPosition;
  }
  public void setPosition( int iPosition ) throws IOException
  {
    if( iPosition < 0 )
    {
      throw new IOException( iPosition + " < 0" );
    }
    _iPosition = iPosition;
  }

  public String getSource()
  {
    return _strSource.toString();
  }

  public static SourceCodeReader makeSourceCodeReader( Reader reader )
  {
    try
    {
      return new SourceCodeReader( StreamUtil.getContent( reader ) );
    }
    catch( IOException e )
    {
      throw new RuntimeException( e );
    }
  }
}
