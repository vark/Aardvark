package gw.lang.parser;

/**
 *  Copyright 2010 Guidewire Software, Inc.
 */
public class ParserSource
{
  private String _strSource;

  public ParserSource( String strSource )
  {
    _strSource = strSource;
  }

  public String getSource()
  {
    return _strSource;
  }
}
