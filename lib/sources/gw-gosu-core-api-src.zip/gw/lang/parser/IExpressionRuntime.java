package gw.lang.parser;

/**
 *  Copyright 2010 Guidewire Software, Inc.
 */
public interface IExpressionRuntime
{
  Object evaluate();
}