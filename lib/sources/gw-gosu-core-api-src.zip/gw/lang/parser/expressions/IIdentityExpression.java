package gw.lang.parser.expressions;

/**
 *  Copyright 2010 Guidewire Software, Inc.
 */
public interface IIdentityExpression extends IConditionalExpression
{
  boolean isEquals();
}