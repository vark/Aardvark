package gw.lang.parser;

import gw.lang.parser.expressions.IDelegateStatement;

/**
 *  Copyright 2010 Guidewire Software, Inc.
 */
public interface IDelegateFunctionSymbol {

  public IDelegateStatement getDelegateStmt();

}
