package gw.lang.parser;

import gw.lang.reflect.IConstructorInfo;

/**
 *  Copyright 2010 Guidewire Software, Inc.
 */
public interface IConstructorFunctionSymbol {

  public IConstructorInfo getConstructorInfo();
  
}
