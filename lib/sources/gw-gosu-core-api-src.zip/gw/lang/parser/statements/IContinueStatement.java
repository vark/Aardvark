package gw.lang.parser.statements;

/**
 *  Copyright 2010 Guidewire Software, Inc.
 */
public interface IContinueStatement extends ITerminalStatement
{
}
