package gw.lang;

/**
 * Marker interface for gosu annotations.  All annotations must extend this
 * interface.
 *
 *  Copyright 2010 Guidewire Software, Inc.
 */
public interface IAnnotation {
}
