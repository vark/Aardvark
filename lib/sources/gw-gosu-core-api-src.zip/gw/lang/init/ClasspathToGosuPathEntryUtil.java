package gw.lang.init;

import gw.config.CommonServices;
import gw.lang.GosuShop;
import gw.lang.UnstableAPI;
import gw.lang.reflect.module.IDirectory;
import gw.lang.reflect.module.IFile;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.io.File;

/**
 * NOTE:  This class is currently not a fixed part of the API and may change in future releases.
 *
 * This class serves as a utility to convert a File-based classpath, such as the Java classpath, into
 * an ordered list of GosuPathEntry objects.
 *
 *  Copyright 2010 Guidewire Software, Inc.
 */
@UnstableAPI
public class ClasspathToGosuPathEntryUtil {

  /**
   * Converts a set of Files into a list of GosuPathEntries.  The algorithm is as follows.  For each File in the list,
   * if that file is a directory or a jar file, see if there's a module.xml file in the root.  If so, parse that file
   * and add in a GosuPathEntry based on the module definition.  If not, if the file is a directory, look for
   * a module.xml file in the parent directory.  If such a file exists, add in a GosuPathEntry based on that file.
   * If no module.xml file has been found in either case, add a GosuPath entry for the directory or jar file using
   * the directory or jar as the root and as the only source directory, and with an empty list of custom typeloaders.
   * If the file is not a directory and not a jar file, ignore it entirely.
   *
   * In all cases, duplicate entries are ignored; if a GosuPathEntry is created previously for a File and the root
   * directory for that previous path entry is equal to or an ancestor of the root directory of the new path entry,
   * the new path entry is not added to the list.
   *
   * @param classpath the list of Files to turn into GosuPathEntries
   * @return an ordered list of GosuPathEntries created based on the algorithm described above
   */
  public static List<? extends GosuPathEntry> convertClasspathToGosuPathEntries(List<File> classpath) {
    List<GosuPathEntry> pathEntries = new ArrayList<GosuPathEntry>();
    for (File f : classpath) {
      boolean isDir = f.isDirectory();
      if (isDir || f.getName().endsWith(".jar")) {
        IDirectory dir = CommonServices.getFileSystem().getIDirectory(f);
        IFile moduleFile = dir.file("module.xml");
        if (moduleFile.exists()) {
          // This entry is itself a module, so return that
          if (!moduleAlreadyIncluded(dir, pathEntries)) {
            pathEntries.add(GosuShop.createPathEntryFromModuleFile(moduleFile));
          }
        } else if (isDir) {
          IDirectory parentDir = dir.getParent();
          if (parentDir != null) {
            IFile parentModuleFile = dir.getParent().file("module.xml");
            if (parentModuleFile.exists()) {
              // Module.xml file in the parent directory, so add that directory as a module
              if (!moduleAlreadyIncluded(parentModuleFile.getParent(), pathEntries)) {
                pathEntries.add(GosuShop.createPathEntryFromModuleFile(parentModuleFile));
              }
            } else {
              // No module.xml file in the parent directory either, so just add the original directory
              if (!moduleAlreadyIncluded(dir, pathEntries)) {
                pathEntries.add(new GosuPathEntry(dir, Collections.singletonList(dir), Collections.<String>emptyList()));
              }
            }
          } else {
            // No parent directory at all, so just add the original directory
            if (!moduleAlreadyIncluded(dir, pathEntries)) {
              pathEntries.add(new GosuPathEntry(dir, Collections.singletonList(dir), Collections.<String>emptyList()));
            }
          }
        } else {
          // It's a jar file with no module.xml inside, so just add it to the path
          if (!moduleAlreadyIncluded(dir, pathEntries)) {
            pathEntries.add(new GosuPathEntry(dir, Collections.singletonList(dir), Collections.<String>emptyList()));
          }
        }
      } else {
        // Ignore anything that's not a directory or jar file
      }      
    }
    return pathEntries;
  }

  private static boolean moduleAlreadyIncluded(IDirectory rootDir, List<GosuPathEntry> pathEntries) {
    for (GosuPathEntry entry : pathEntries) {
      if (rootDir.equals(entry.getRoot()) || rootDir.isDescendantOf(entry.getRoot())) {
        return true;
      }
    }

    return false;
  }
}
