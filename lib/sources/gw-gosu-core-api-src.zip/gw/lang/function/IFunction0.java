package gw.lang.function;

/**
 *  Copyright 2010 Guidewire Software, Inc.
 */
@SuppressWarnings({"UnusedDeclaration"})
public interface IFunction0 extends IBlock { 

  public Object invoke();

}
