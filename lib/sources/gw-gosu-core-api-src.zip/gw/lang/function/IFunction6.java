package gw.lang.function;

/**
 *  Copyright 2010 Guidewire Software, Inc.
 */
@SuppressWarnings({"UnusedDeclaration"})
public interface IFunction6 extends IBlock { 

  public Object invoke(Object arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5);

}
