package gw.lang.function;

/**
 *  Copyright 2010 Guidewire Software, Inc.
 */
@SuppressWarnings({"UnusedDeclaration"})
public interface IFunction2 extends IBlock { 

  public Object invoke(Object arg0, Object arg1);

}
