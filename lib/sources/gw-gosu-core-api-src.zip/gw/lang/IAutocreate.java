package gw.lang;

/**
 *  Copyright 2010 Guidewire Software, Inc.
 */
public interface IAutocreate
{
  public Object getBlock();
}
