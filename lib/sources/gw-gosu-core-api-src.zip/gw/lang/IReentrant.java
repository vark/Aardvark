package gw.lang;

/**
 *  Copyright 2010 Guidewire Software, Inc.
 */
public interface IReentrant
{
  void enter();
  void exit();
}
