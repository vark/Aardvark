package gw.lang.cli;

/**
 *  Copyright 2010 Guidewire Software, Inc.
 */
public class SystemExitIgnoredException extends RuntimeException {
}
