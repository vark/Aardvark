package gw.fs.jar;

import gw.fs.ResourcePath;
import gw.lang.UnstableAPI;
import gw.lang.reflect.module.IResource;
import gw.lang.reflect.module.IDirectory;

import java.io.IOException;
import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.jar.JarEntry;

/**
 *  Copyright 2010 Guidewire Software, Inc.
 */
@UnstableAPI
public abstract class JarEntryResourceImpl implements IResource {

  protected JarEntry _entry;
  protected IJarFileDirectory _parent;
  protected JarFileDirectoryImpl _jarFile;
  protected String _name;
  private boolean _exists = false;

  protected JarEntryResourceImpl(String name, IJarFileDirectory parent, JarFileDirectoryImpl jarFile) {
    _name = name;
    _parent = parent;
    _jarFile = jarFile;
  }

  public void setEntry(JarEntry entry) {
    _entry = entry;
    setExists();
  }

  protected void setExists() {
    _exists = true;
    if (getParent() instanceof JarEntryResourceImpl) {
      ((JarEntryResourceImpl) getParent()).setExists();
    }
  }

  @Override
  public IDirectory getParent() {
    return _parent;
  }

  @Override
  public String getName() {
    return _name;
  }

  @Override
  public boolean exists() {
    return _exists;
  }

  @Override
  public boolean delete() throws IOException {
    throw new UnsupportedOperationException();
  }

  @Override
  public URI toURI() {
    try {
      return new URI("jar:" + _jarFile.toURI().toString() + "!/" + getEntryName());
    } catch (URISyntaxException e) {
      throw new RuntimeException(e);
    }
  }

  private String getEntryName() {
    if (_entry != null) {
      return _entry.getName();
    } else {
      String result = _name;
      IDirectory parent = _parent;
      while (!(parent instanceof JarFileDirectoryImpl)) {
        result = parent.getName() + "/" + result;
        parent = parent.getParent();
      }
      return result;
    }
  }

  @Override
  public String getPath() {
    return _parent.getPath() + "/" + _name;
  }

  @Override
  public String getAbsolutePath() {
    return _parent.getAbsolutePath() + "/" + _name;
  }

  @Override
  public ResourcePath getResourcePath() {
    return ResourcePath.parse(getAbsolutePath());
  }

  @Override
  public boolean isChildOf(IDirectory dir) {
    return dir.equals(getParent());
  }

  @Override
  public boolean isDescendantOf(IDirectory dir) {
    // TODO - AHK
    return getPath().startsWith(dir.getPath());
  }

  @Override
  public File toJavaFile() {
    throw new UnsupportedOperationException();
  }

  @Override
  public boolean isJavaFile() {
    return false;
  }

  @Override
  public String toString() {
    return getPath();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == this) {
      return true;
    }

    if (obj instanceof JarEntryResourceImpl) {
      return getPath().equals(((JarEntryResourceImpl) obj).getPath());
    } else {
      return false;
    }
  }
}
