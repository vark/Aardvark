package gw.fs.jar;

import gw.lang.UnstableAPI;
import gw.lang.reflect.module.IDirectory;

/**
 *  Copyright 2010 Guidewire Software, Inc.
 */
@UnstableAPI
public interface IJarFileDirectory extends IDirectory {
  JarEntryDirectoryImpl getOrCreateDirectory(String relativeName);
  JarEntryFileImpl getOrCreateFile(String relativeName);
}
