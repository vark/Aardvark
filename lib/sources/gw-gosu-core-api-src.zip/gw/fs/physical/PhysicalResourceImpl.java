package gw.fs.physical;

import gw.fs.ResourcePath;
import gw.lang.UnstableAPI;
import gw.lang.reflect.module.IDirectory;
import gw.lang.reflect.module.IResource;

import java.io.File;
import java.io.IOException;
import java.net.URI;

/**
 *  Copyright 2010 Guidewire Software, Inc.
 */
@UnstableAPI
public class PhysicalResourceImpl implements IResource {
  protected final ResourcePath _path;
  protected final IPhysicalFileSystem _backingFileSystem;

  protected PhysicalResourceImpl(ResourcePath path, IPhysicalFileSystem backingFileSystem) {
    _path = path;
    _backingFileSystem = backingFileSystem;
  }

  @Override
  public IDirectory getParent() {
    if (_path.getParent() == null) {
      return null;
    } else {
      return new PhysicalDirectoryImpl(_path.getParent(), _backingFileSystem);
    }
  }

  @Override
  public String getName() {
    return _path.getName();
  }

  @Override
  public boolean exists() {
    return getIFileMetadata().exists();
  }

  @Override
  public boolean delete() throws IOException {
    return _backingFileSystem.delete(_path);
  }

  @Override
  public URI toURI() {
    // TODO - AHK - Where does this properly belong?
    return toJavaFile().toURI();
  }

  @Override
  public String getPath() {
    // TODO - AHK - Should this be an absolute path, or canonical path?
    return _path.getPathString();
  }

  @Override
  public String getAbsolutePath() {
    return _path.getPathString();
  }

  @Override
  public ResourcePath getResourcePath() {
    return _path;
  }

  @Override
  public boolean isChildOf(IDirectory dir) {
    // TODO - AHK - If IFile/IDirectory change to use ResourcePath, check for IResource instead
    if (dir instanceof PhysicalResourceImpl) {
      return ((PhysicalResourceImpl) dir)._path.isChild(_path);
    } else {
      return false;
    }
  }

  @Override
  public boolean isDescendantOf( IDirectory dir ) {
    // TODO - AHK - If IFile/IDirectory change to use ResourcePath, check for IResource instead
    if (dir instanceof PhysicalResourceImpl) {
      return ((PhysicalResourceImpl) dir)._path.isDescendent(_path);
    } else {
      return false;
    }
  }

  @Override
  public File toJavaFile() {
    return new File(_path.getPathString());
  }

  @Override
  public boolean isJavaFile() {
    return true;
  }

  @Override
  public boolean equals(Object obj) {
    // TODO - AHK - If IFile/IDirectory change to use ResourcePath, check for IResource instead
    if (obj instanceof PhysicalResourceImpl) {
      return _path.equals(((PhysicalResourceImpl) obj)._path);
    } else {
      return false;
    }
  }

  @Override
  public String toString() {
    return getAbsolutePath();
  }
  
  protected IFileMetadata getIFileMetadata() {
    // TODO - AHK - Should this always be cached?  Sometimes?  Never?
    return _backingFileSystem.getFileMetadata(_path);
  }
}
