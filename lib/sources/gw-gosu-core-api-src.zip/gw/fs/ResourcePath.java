package gw.fs;

import gw.lang.UnstableAPI;
import gw.util.GosuObjectUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 *  Copyright 2010 Guidewire Software, Inc.
 */
@UnstableAPI
public class ResourcePath {
  // TODO - AHK - Could even do some pooling here (essentially interning) to avoid memory explosion
  private final ResourcePath _parent;
  private final String _name;

  // TODO - AHK - Should this really be public?
  public ResourcePath(ResourcePath parent, String name) {
    _parent = parent;
    _name = name; // TODO - AHK - Trim the memory by constructing a new String?
  }

  private ResourcePath(List<String> fullPath) {
    _name = fullPath.remove(fullPath.size() - 1); // TODO - AHK - Trim the memory by constructing a new String?
    if (!fullPath.isEmpty()) {
      _parent = new ResourcePath(fullPath);
    } else {
      _parent = null;
    }
  }

  public static ResourcePath parse(String pathString) {
    // TODO - AHK - Handle stuff like drive letters and such?

    List<String> results = new ArrayList<String>();
    char first = pathString.charAt(0);
    if (first == '/' || first=='\\') {
      pathString = pathString.substring(1);
    }
    char last = pathString.charAt(pathString.length() - 1);
    if (last == '/' || last == '\\') {
      pathString = pathString.substring(0, pathString.length() - 1);
    }
    int lastIndex = 0;
    for (int i = 0; i < pathString.length(); i++) {
      char c = pathString.charAt(i);
      if (c == '/' || c == '\\') {
        results.add(pathString.substring(lastIndex, i));
        lastIndex = i + 1;
      }
    }

    pathString = pathString.substring(lastIndex);
    // Discard single dots at this point; they don't impact the path at all, so just throw them out
    if (!".".equals(pathString)) {
      results.add(pathString);
    }

    return new ResourcePath(results);
  }

  public String getName() {
    return _name;
  }

  public ResourcePath getParent() {
    return _parent;
  }

  public String getPathString() {
    // TODO - AHK
//    return getPathString("/");
    return getFileSystemPathString();
  }

  public String getFileSystemPathString() {
    return getPathString(File.separator);
  }

  public String getPathString(String separator) {
    StringBuilder sb = new StringBuilder();
    constructPathString(sb, separator);
    return sb.toString();
  }

  private void constructPathString(StringBuilder sb, String separator) {
    if (_parent != null) {
      _parent.constructPathString(sb, separator);
      sb.append(separator);
    }
    sb.append(_name);
  }

  public ResourcePath join(ResourcePath otherPath) {
    ResourcePath result;
    if (otherPath.getParent() != null) {
      result = join(otherPath.getParent());
    } else {
      result = this;
    }

    if (otherPath.getName().equals(".")) {
      return result;
    } else if (otherPath.getName().equals("..")) {
      return result.getParent();
    } else {
      return new ResourcePath(result, otherPath.getName());
    }
  }

  @Override
  public boolean equals(Object obj) {
    if (obj instanceof ResourcePath) {
      ResourcePath otherPath = (ResourcePath) obj;
      return otherPath.getName().equals(getName()) && GosuObjectUtil.equals(getParent(), otherPath.getParent());
    } else {
      return false;
    }
  }

  public boolean isChild(ResourcePath path) {
    return GosuObjectUtil.equals(this, path.getParent());
  }

  public boolean isDescendent(ResourcePath path) {
    ResourcePath pathToTest = path;
    while (pathToTest != null) {
      if (pathToTest.equals(this)) {
        return true;
      }
      pathToTest = pathToTest.getParent();
    }

    return false;
  }

  public ResourcePath relativePath(ResourcePath other) {
    // TODO - AHK
    return null;
  }
}
